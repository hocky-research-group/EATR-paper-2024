#!/bin/bash

cd run_$1
plumed pesmd < pesmd.input
